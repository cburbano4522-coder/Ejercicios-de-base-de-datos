CREATE DATABASE IF NOT EXISTS hospital;
USE hospital;


CREATE TABLE IF NOT EXISTS pacientes (
    n_historia_clinica INT PRIMARY KEY NOT NULL,
    nombre_paciente VARCHAR(50) NOT NULL,
    direccion_paciente VARCHAR(60) NOT NULL,
    telefono_paciente VARCHAR(20) NOT NULL
);


CREATE TABLE IF NOT EXISTS medicos (
    n_colegiatura INT PRIMARY KEY NOT NULL,
    nombre_medico VARCHAR(50) NOT NULL,
    especialidad VARCHAR(50) NOT NULL
);


CREATE TABLE IF NOT EXISTS citas (
    id_cita INT PRIMARY KEY NOT NULL,
    fecha_cita DATE NOT NULL,
    hora_cita TIME NOT NULL,
    n_historia_clinica INT NOT NULL,
    n_colegiatura INT NOT NULL,

    CONSTRAINT fk_cita_paciente FOREIGN KEY (n_historia_clinica)
        REFERENCES pacientes(n_historia_clinica),
    CONSTRAINT fk_cita_medico FOREIGN KEY (n_colegiatura)
        REFERENCES medicos(n_colegiatura)
);
