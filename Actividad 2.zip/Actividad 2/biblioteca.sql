CREATE DATABASE IF NOT EXISTS biblioteca;
USE biblioteca;

CREATE TABLE IF NOT EXISTS usuarios (
numero_usuario INT PRIMARY KEY NOT NULL,
direccion VARCHAR(40) NOT NULL,
nombre_usuario VARCHAR(40) NOT NULL 
);

CREATE TABLE IF NOT EXISTS libros (
codigo_libro INT PRIMARY KEY NOT NULL,
titulo VARCHAR(40) NOT NULL,
autor VARCHAR(40)NOT NULL,
año_publicacion DATE NOT NULL
); 

CREATE TABLE IF NOT EXISTS prestamos (
id_prestamo INT PRIMARY KEY NOT NULL,
numero_usuario INT NOT NULL,
codigo_libro INT NOT NULL,

CONSTRAINT fk_prestamo_usuario FOREIGN KEY (numero_usuario) REFERENCES usuarios(numero_usuario),
CONSTRAINT fk_prestamo_libro FOREIGN KEY (codigo_libro) REFERENCES libros(codigo_libro)
);